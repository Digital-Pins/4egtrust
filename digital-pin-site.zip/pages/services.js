export default function Services() {
  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Our Services</h1>
      <ul className="list-disc pl-6">
        <li>ERP Development (Dolibarr customization)</li>
        <li>Digital Transformation</li>
        <li>Engineering Fabrication</li>
      </ul>
    </main>
  )
}
