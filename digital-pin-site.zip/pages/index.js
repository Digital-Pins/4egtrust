export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
      <h1 className="text-4xl font-bold text-blue-800">Welcome to Digital PIN LLC</h1>
      <p className="mt-4 text-lg text-gray-600">ERP Development • Digital Transformation • Engineering Solutions</p>
    </main>
  )
}
