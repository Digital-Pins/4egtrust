export default function Projects() {
  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Selected Projects</h1>
      <ul className="list-disc pl-6">
        <li>Dolibarr Custom ERP</li>
        <li>PIN AI ATC</li>
        <li>PIN Learn Project</li>
        <li>PIN KIT</li>
      </ul>
    </main>
  )
}
