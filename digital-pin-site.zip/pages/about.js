export default function About() {
  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">About Us</h1>
      <p>Digital PIN LLC is an Egyptian joint-stock company (LLC) delivering high-quality digital and engineering solutions.</p>
    </main>
  )
}
