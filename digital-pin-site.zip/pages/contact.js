export default function Contact() {
  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Contact Us</h1>
      <p>Email: ceo@4egtrust.com</p>
      <p>Phone: [Insert Phone]</p>
    </main>
  )
}
