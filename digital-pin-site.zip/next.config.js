/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export', // Static Export for Cloudflare Pages
}

module.exports = nextConfig
